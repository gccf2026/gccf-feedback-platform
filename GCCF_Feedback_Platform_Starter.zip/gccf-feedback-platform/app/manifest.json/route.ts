import { NextResponse } from "next/server";
export async function GET() {
 return NextResponse.json({name:"GCCF Feedback Centre",short_name:"GCCF Feedback",start_url:"/",display:"standalone",background_color:"#f7f2e9",theme_color:"#690b2c",icons:[]});
}