 "use client";
import { useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

export default function Home() {
  const [kind,setKind] = useState("General feedback");
  const [privacy,setPrivacy] = useState("anonymous");
  const [rating,setRating] = useState("5");
  const [message,setMessage] = useState("");
  const [name,setName] = useState("");
  const [contact,setContact] = useState("");
  const [busy,setBusy] = useState(false);
  const [result,setResult] = useState("");
  const configured = Boolean(supabaseUrl && supabaseKey && !supabaseUrl.includes("YOUR_PROJECT"));

  async function submit(e:React.FormEvent) {
    e.preventDefault(); setResult("");
    if (!configured) { setResult("The platform is not connected to its Supabase database yet. Configure the environment variables and run the database migration."); return; }
    if (message.trim().length < 10) { setResult("Please provide at least 10 characters of feedback."); return; }
    if (privacy === "identified" && !name.trim()) { setResult("Please enter your name, or choose anonymous feedback."); return; }
    setBusy(true);
    const { error } = await supabase.rpc("submit_public_feedback", {
      p_category: kind, p_rating: Number(rating), p_message: message.trim(),
      p_is_anonymous: privacy === "anonymous",
      p_submitter_name: privacy === "identified" ? name.trim() : null,
      p_contact: privacy === "identified" ? contact.trim() || null : null
    });
    setBusy(false);
    if (error) setResult("Submission could not be completed. Please try again later.");
    else { setResult("Thank you. Your feedback has been securely submitted."); setMessage(""); setName(""); setContact(""); }
  }

  return <main>
    <header className="hero">
      <div className="brandMark">✝</div>
      <p className="eyebrow">GLOBAL CHRISTIAN</p>
      <h1>CORPORATE FELLOWSHIP</h1>
      <p className="tagline">Where Faith Meets Leadership</p>
      <p className="intro">Your voice matters. Help us grow together in faith, fellowship and service.</p>
    </header>
    <section className="panel">
      <div className="sectionHead"><span className="kicker">GCCF FEEDBACK CENTRE</span><h2>Share your feedback</h2><p>Members and visitors can submit feedback without creating an account.</p></div>
      <form onSubmit={submit}>
        <label>Feedback category<select value={kind} onChange={e=>setKind(e.target.value)}>{["General feedback","Church services","Leadership and administration","Worship and praise","Pastoral care and prayer","Fellowship and community","Events and conferences","Mobilisation","Finance","Suggestion","Complaint"].map(x=><option key={x}>{x}</option>)}</select></label>
        <label>How would you rate your experience?<select value={rating} onChange={e=>setRating(e.target.value)}>{[5,4,3,2,1].map(x=><option value={x} key={x}>{x} — {["","Poor","Fair","Good","Very good","Excellent"][x]}</option>)}</select></label>
        <label>Your message<textarea required minLength={10} maxLength={5000} rows={6} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Share your experience, concern, testimony or suggestion…"/></label>
        <fieldset><legend>Privacy preference</legend>
          <label className="choice"><input type="radio" checked={privacy==="anonymous"} onChange={()=>setPrivacy("anonymous")}/> Anonymous — do not attach my identity</label>
          <label className="choice"><input type="radio" checked={privacy==="identified"} onChange={()=>setPrivacy("identified")}/> Identified — I would like the team to contact me</label>
        </fieldset>
        {privacy==="identified" && <div className="two"><label>Name<input value={name} onChange={e=>setName(e.target.value)} maxLength={120} placeholder="Your name"/></label><label>Phone or email (optional)<input value={contact} onChange={e=>setContact(e.target.value)} maxLength={160} placeholder="Your contact details"/></label></div>}
        <button disabled={busy}>{busy?"Submitting…":"Submit feedback securely"}</button>
        {result && <p role="status" className="notice">{result}</p>}
        <p className="privacy"><span>🔒</span> Your privacy matters. Anonymous submissions do not include your name or contact details.</p>
      </form>
    </section>
    <footer>GLOBAL CHRISTIAN CORPORATE FELLOWSHIP <span>•</span> Where Faith Meets Leadership</footer>
  </main>;
}