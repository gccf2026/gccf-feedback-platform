import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "GCCF Feedback Centre",
  description: "Global Christian Corporate Fellowship — Where Faith Meets Leadership",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "GCCF Feedback" }
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}