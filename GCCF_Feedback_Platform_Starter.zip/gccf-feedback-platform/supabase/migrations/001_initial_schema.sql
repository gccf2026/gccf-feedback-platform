-- GCCF production database baseline. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.gccf_role as enum ('chairman','administrator_secretary','mobilizer','finance');
create type public.feedback_status as enum ('new','under_review','assigned','resolved','closed');

create table public.staff_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.gccf_role not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  category text not null check (char_length(category) between 2 and 80),
  rating smallint not null check (rating between 1 and 5),
  message text not null check (char_length(message) between 10 and 5000),
  is_anonymous boolean not null default true,
  submitter_name text,
  contact text,
  status public.feedback_status not null default 'new',
  assigned_to uuid references public.staff_profiles(user_id),
  internal_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint anonymous_has_no_identity check (
    is_anonymous = false or (submitter_name is null and contact is null)
  )
);

create table public.feedback_activity (
  id uuid primary key default gen_random_uuid(),
  feedback_id uuid not null references public.feedback(id) on delete cascade,
  actor uuid references public.staff_profiles(user_id),
  action text not null,
  details text,
  created_at timestamptz not null default now()
);

create index feedback_created_at_idx on public.feedback(created_at desc);
create index feedback_status_idx on public.feedback(status);
create index feedback_category_idx on public.feedback(category);

alter table public.staff_profiles enable row level security;
alter table public.feedback enable row level security;
alter table public.feedback_activity enable row level security;

create or replace function public.current_gccf_role()
returns public.gccf_role language sql stable security definer
set search_path = '' as $$
  select role from public.staff_profiles
  where user_id = auth.uid() and active = true
$$;

-- Public users cannot select, update or delete feedback.
-- Anonymous/identified public intake is only through the constrained RPC below.
revoke all on public.feedback from anon, authenticated;
revoke all on public.feedback_activity from anon, authenticated;
revoke all on public.staff_profiles from anon, authenticated;

-- Table privileges are granted only to authenticated staff; RLS remains the
-- row-level gate. Anonymous users receive no direct table privileges.
grant select on public.staff_profiles to authenticated;
grant select, update on public.feedback to authenticated;
grant select on public.feedback_activity to authenticated;

create policy "staff can read own profile"
on public.staff_profiles for select to authenticated
using (user_id = auth.uid());

create policy "chairman and secretary can read feedback"
on public.feedback for select to authenticated
using (public.current_gccf_role() in ('chairman','administrator_secretary'));

create policy "mobilizer sees mobilisation feedback"
on public.feedback for select to authenticated
using (public.current_gccf_role() = 'mobilizer' and category in ('Mobilisation','Events and conferences','Fellowship and community'));

create policy "finance sees finance feedback"
on public.feedback for select to authenticated
using (public.current_gccf_role() = 'finance' and category = 'Finance');

create policy "chairman and secretary can update feedback"
on public.feedback for update to authenticated
using (public.current_gccf_role() in ('chairman','administrator_secretary'))
with check (public.current_gccf_role() in ('chairman','administrator_secretary'));

create policy "mobilizer can update mobilisation feedback"
on public.feedback for update to authenticated
using (public.current_gccf_role() = 'mobilizer' and category in ('Mobilisation','Events and conferences','Fellowship and community'))
with check (public.current_gccf_role() = 'mobilizer' and category in ('Mobilisation','Events and conferences','Fellowship and community'));

create policy "finance can update finance feedback"
on public.feedback for update to authenticated
using (public.current_gccf_role() = 'finance' and category = 'Finance')
with check (public.current_gccf_role() = 'finance' and category = 'Finance');

create policy "staff can read permitted activity"
on public.feedback_activity for select to authenticated
using (exists (
  select 1 from public.feedback f where f.id = feedback_id
));

-- Narrow public intake function: validates inputs, strips identity for anonymous entries,
-- and returns only a success boolean. No public read access is granted.
create or replace function public.submit_public_feedback(
  p_category text,
  p_rating integer,
  p_message text,
  p_is_anonymous boolean default true,
  p_submitter_name text default null,
  p_contact text default null
) returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  clean_category text := left(trim(coalesce(p_category,'')),80);
  clean_message text := trim(coalesce(p_message,''));
begin
  if char_length(clean_category) < 2 then raise exception 'Invalid category'; end if;
  if p_rating < 1 or p_rating > 5 then raise exception 'Invalid rating'; end if;
  if char_length(clean_message) < 10 or char_length(clean_message) > 5000 then raise exception 'Invalid message'; end if;
  if p_is_anonymous then
    insert into public.feedback(category,rating,message,is_anonymous,submitter_name,contact)
    values(clean_category,p_rating,clean_message,true,null,null);
  else
    if char_length(trim(coalesce(p_submitter_name,''))) < 2 then raise exception 'Name required'; end if;
    insert into public.feedback(category,rating,message,is_anonymous,submitter_name,contact)
    values(clean_category,p_rating,clean_message,false,left(trim(p_submitter_name),120),left(trim(coalesce(p_contact,'')),160));
  end if;
  return true;
end;
$$;

revoke all on function public.submit_public_feedback(text,integer,text,boolean,text,text) from public;
grant execute on function public.submit_public_feedback(text,integer,text,boolean,text,text) to anon, authenticated;

-- Prevent ordinary staff from creating or promoting staff profiles.
-- Provision role assignments only from a trusted server/admin process.
grant usage on schema public to anon, authenticated;
